<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<!-- Nav Bar Starts here -->

<?php echo $__env->make('layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->yieldContent('content'); ?>
<!-- Nav Bar Ends here -->
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/xhvraomy/public_html/visa-insurance-greenberrysignature-co-in/resources/views/layout/commonlayout.blade.php ENDPATH**/ ?>