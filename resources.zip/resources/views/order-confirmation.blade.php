@extends('layout.commonlayout')
@section('content')


<!-- Form section start here -->
<div class="section-larger">
	<div class="container">
	
		<div class="row">
			<div class="col-lg-6 m-auto">
			<div class="ordr-confirm">
				<h4>Thank you!</h4>
				<p>Dear Applicant </p>
				<h6>We have received your Insurance policy request.<br />
					We will get in touch with you soon.</h6>
			</div>
		</div>
	 </div>
	</div>
</div>
<!-- Form section Ends here -->



@endsection